-- use S2_BDD;
DROP TABLE IF EXISTS cable;
DROP TABLE IF EXISTS longueur;
DROP TABLE IF EXISTS type_prise;
DROP TABLE IF EXISTS ligne_panier;
DROP TABLE IF EXISTS commande;
DROP TABLE IF EXISTS etat;
DROP TABLE IF EXISTS ligne_commande;
DROP TABLE IF EXISTS utilisateur;

CREATE TABLE type_prise(
   id_type_prise INT AUTO_INCREMENT,
   nom_type_prise VARCHAR(50),
   PRIMARY KEY(id_type_prise)
);

CREATE TABLE longueur(
   id_longueur INT AUTO_INCREMENT,
   nom_longueur VARCHAR(50),
   PRIMARY KEY(id_longueur)
);

CREATE TABLE utilisateur(
   id_utilisateur INT AUTO_INCREMENT,
   login VARCHAR(255),
   email VARCHAR(255),
   nom VARCHAR(50),
   password VARCHAR(255),
   role VARCHAR(255),
   PRIMARY KEY(id_utilisateur)
);

CREATE TABLE etat(
   id_etat INT AUTO_INCREMENT,
   libelle VARCHAR(255),
   PRIMARY KEY(id_etat)
);

CREATE TABLE cable(
   id_cable INT AUTO_INCREMENT,
   nom_cable VARCHAR(50),
   couleur VARCHAR(50),
   prix_cable DECIMAL(15,2),
   blindage VARCHAR(50),
   fournisseur VARCHAR(50),
   marque VARCHAR(50),
   photo VARCHAR(50),
   stock INT,
   type_prise_id INT NOT NULL,
   longueur_id INT NOT NULL,
   PRIMARY KEY(id_cable),
   FOREIGN KEY(type_prise_id) REFERENCES type_prise(id_type_prise),
   FOREIGN KEY(longueur_id) REFERENCES longueur(id_longueur)
);

CREATE TABLE commande(
   id_commande INT AUTO_INCREMENT,
   date_achat DATE,
   etat_id INT NOT NULL,
   utilisateur_id INT NOT NULL,
   PRIMARY KEY(id_commande),
   FOREIGN KEY(etat_id) REFERENCES etat(id_etat),
   FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id_utilisateur)
);

CREATE TABLE ligne_commande(
   cable_id INT,
   commande_id INT,
   quantite_commande INT,
   prix DECIMAL(15,2),
   PRIMARY KEY(cable_id, commande_id),
   FOREIGN KEY(cable_id) REFERENCES cable(id_cable),
   FOREIGN KEY(commande_id) REFERENCES commande(id_commande)
);

CREATE TABLE ligne_panier(
   cable_id INT,
   utilisateur_id INT,
   quantite_panier INT,
   date_ajout DATE,
   PRIMARY KEY(cable_id, utilisateur_id),
   FOREIGN KEY(cable_id) REFERENCES cable(id_cable),
   FOREIGN KEY(utilisateur_id) REFERENCES utilisateur(id_utilisateur)
);


-- =========================
-- 1) TABLES DE REFERENCE
-- =========================

INSERT INTO type_prise (nom_type_prise) VALUES
('USB-A vers USB-C'),
('USB-C vers USB-C'),
('Lightning'),
('Micro-USB'),
('Jack 3.5mm');

INSERT INTO longueur (nom_longueur) VALUES
('0.5 m'),
('1 m'),
('2 m'),
('3 m'),
('5 m');

INSERT INTO etat (id_etat, libelle) VALUES
(1, 'en attente'),
(2, 'payée'),
(3, 'expédiée'),
(4, 'livrée'),
(5, 'annulée');

-- =========================
-- 2) UTILISATEURS
-- =========================

    INSERT INTO utilisateur(id_utilisateur,login,email,password,role,nom) VALUES
(1,'admin','admin@admin.fr',
    'pbkdf2:sha256:1000000$eQDrpqICHZ9eaRTn$446552ca50b5b3c248db2dde6deac950711c03c5d4863fe2bd9cef31d5f11988',
    'ROLE_admin','admin'),
(2,'client','client@client.fr',
    'pbkdf2:sha256:1000000$jTcSUnFLWqDqGBJz$bf570532ed29dc8e3836245f37553be6bfea24d19dfb13145d33ab667c09b349',
    'ROLE_client','client'),
(3,'client2','client2@client2.fr',
    'pbkdf2:sha256:1000000$qDAkJlUehmaARP1S$39044e949f63765b785007523adcde3d2ad9c2283d71e3ce5ffe58cbf8d86080',
    'ROLE_client','client2');

-- =========================
-- 3) CABLES
--   #Id_type_prise et #Id_longueur
--   (ici on suppose que les insert précédents ont créé:
--    type_prise: 1..5 et longueur: 1..5)
-- =========================

INSERT INTO cable
(nom_cable, couleur, prix_cable, blindage, fournisseur, marque, photo, stock, Id_type_prise, Id_longueur)
VALUES
('Câble FastCharge', 'noir', 9.90, 'tressé', 'TechSupply', 'Voltix', 'fastcharge_noir.jpg', 120, 1, 2),
('Câble Nylon Pro', 'rouge', 14.90, 'nylon', 'TechSupply', 'Voltix', 'nylon_pro_rouge.jpg', 3, 2, 3),
('Câble Lightning MFi', 'blanc', 19.90, 'standard', 'AppleDist', 'Pear', 'lightning_blanc.jpg', 40, 3, 2),
('Câble Micro-USB', 'bleu', 6.50, 'standard', 'BulkImport', 'Generic', 'microusb_bleu.jpg', 200, 4, 4),
('Câble Audio Jack', 'noir', 7.90, 'blindé', 'SoundPro', 'AudioMax', 'jack_noir.jpg', 75, 5, 5);

-- On suppose maintenant que les câbles générés ont Id_cable = 1..5

-- =========================
-- 4) COMMANDES
-- =========================

INSERT INTO commande (id_commande, date_achat, id_etat, id_utilisateur) VALUES
(1001, '2026-01-10', 4, 1),
(1002, '2026-01-15', 2, 1),
(1003, '2026-01-20', 1, 2);
-- =========================
-- 5) LIGNES DE COMMANDE
--   (prix INT chez toi, donc je mets un prix en entier (ex: centimes)
--   ou un prix "arrondi". Je pars sur des centimes pour être propre.)
-- =========================

INSERT INTO ligne_commande (Id_cable, id_commande, quantite_commande, prix) VALUES
(1, 1001, 2, 990),
(5, 1001, 1, 790),
(3, 1002, 1, 1990),
(2, 1002, 2, 1490),
(4, 1003, 3, 650);

-- =========================
-- 6) PANIER
-- =========================

INSERT INTO ligne_panier (Id_cable, id_utilisateur, quantite_panier, date_ajout) VALUES
(2, 1, 1, '2026-01-29'),
(5, 1, 2, '2026-01-28'),
(1, 2, 1, '2026-01-27'),
(3, 2, 1, '2026-01-29');